package org.apache.dubbo.springboot.demo.consumer.Listener;

import org.springframework.stereotype.Component;

@Component
public class ConsumerListener extends AbstractMessageListener<String, byte[]>{
    @Override
    protected void onConsumer(String msg) {
        System.out.println(msg);
    }
}
